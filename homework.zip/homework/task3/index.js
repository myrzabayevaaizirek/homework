
const thumbnails = document.querySelectorAll('.thumbnail');


const lightbox = document.getElementById('lightbox');
const lightboxImage = document.getElementById('lightbox-image');
const closeBtn = document.getElementById('close-btn');


thumbnails.forEach(thumbnail => {
    thumbnail.addEventListener('click', function() {
        lightbox.style.display = 'flex';  
        lightboxImage.src = this.src;   
        lightboxImage.alt = this.alt;    
    });
});


closeBtn.addEventListener('click', function() {
    lightbox.style.display = 'none'; 
});

lightbox.addEventListener('click', function(event) {
    if (event.target === lightbox) {
        lightbox.style.display = 'none';
    }
});
