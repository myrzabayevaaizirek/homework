document.getElementById('registration-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    let isValid = true;
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (name.trim() === '') {
        document.getElementById('name-error').textContent = 'Имя не может быть пустым';
        isValid = false;
    } else {
        document.getElementById('name-error').textContent = '';
    }

    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        document.getElementById('email-error').textContent = 'Email должен содержать "@" и "."';
        isValid = false;
    } else {
        document.getElementById('email-error').textContent = '';
    }


    if (password.length < 8) {
        document.getElementById('password-error').textContent = 'Пароль должен содержать минимум 8 символов';
        isValid = false;
    } else {
        document.getElementById('password-error').textContent = '';
    }

    if (isValid) {
        alert('Форма успешно отправлена!');
    }
});
